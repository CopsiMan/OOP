#pragma once

#include <qwidget.h>
#include "RepositoryInterface.h"
#include "Service.h"
#include <qlistwidget.h>
#include <qlineedit.h>
#include <qpushbutton.h>
#include <qlayout.h>
#include <qtabwidget.h>
#include <QtCharts/QtCharts>
#include <qbarseries.h>
#include <qbarset.h>


#define USER_MODE 1
#define LIST_FILMED_AT 0
#define LIST_ACCES_COUNT 1
#define DAY 1
#define MONTH 0
#define YEAR 2

using namespace std;

class GUI : public QWidget
{
private:
	Service* service;
	QListWidget* tapesListWidget;
	QTabWidget* tabs;
	QTabWidget* chartTab;
	QPushButton* addButton, * deleteButton, * updateButton;
	QLineEdit* titleLineEdit, * locationLineEdit, * dateLineEdit, * accessCountLineEdit, * previewLineEdit;

public:
	GUI(std::string path);
	void init();
	void populateList();
	void drawChart();
	int getSelectedIndex();
	void connectSignalsAndSlots();
	void add();
	void destroy();
	void update();
	std::vector<std::string> GUI::splitString(std::string stringToSplit, char delimiter);

};

