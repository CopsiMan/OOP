#include "Tape.h"

//Tape::Tape()
//{
//	this->title = '-';
//	this->filmedAt = '-';
//	this->creationDate = Date{};
//	this->accessCount = 0;
//	this->footagePreview = '-';
//}

Tape::Tape(std::string title, std::string filmedAt, Date creationDate, int accessCount, std::string footagePreview)
{
	this->setTitle(title);
	this->setFilmedAt(filmedAt);
	this->setCreationDate(creationDate);
	this->setAccessCount(accessCount);
	this->setFootagePreview(footagePreview);
}

Tape::Tape(const Tape& tape)
{
	this->title = tape.getTitle();
	this->creationDate = tape.getCreationDate();
	this->filmedAt = tape.getFilmedAt();
	this->accessCount = tape.getAccessCount();
	this->footagePreview = tape.getFootagePreview();
}

std::string Tape::getTitle() const
{
	return this->title;
}

int Tape::getAccessCount() const
{
	return this->accessCount;
}

std::string Tape::setTitle(std::string title)
{
	if (title.size() == 0)
		throw "Invalid title length";
	this->title = title;
	return this->title;
}

std::string Tape::setFilmedAt(std::string filmedAt)
{
	if (filmedAt.size() == 0)
		throw "Invalid filmedAt length";
	this->filmedAt = filmedAt;
	return this->filmedAt;
}

Date Tape::setCreationDate(Date creationDate)
{
	if (creationDate.valid() == false)
		throw "Invalid creationDate";
	this->creationDate = creationDate;
	return this->creationDate;
}

std::string Tape::setFootagePreview(std::string footagePreview)
{
	if (footagePreview.size() == 0)
		throw "Invalid footagePreview length";
	this->footagePreview = footagePreview;
	return this->footagePreview;
}

int Tape::setAccessCount(int accessCount)
{
	if (accessCount < 0)
		throw "Invalid acces count value!";
	this->accessCount = accessCount;
	return accessCount;
}

Tape& Tape::operator=(const Tape& tape)
{
	this->title = tape.title;
	this->filmedAt = tape.filmedAt;
	this->creationDate = tape.creationDate;
	this->accessCount = tape.accessCount;
	this->footagePreview = tape.footagePreview;
	//delete tape;
	return *this;
}

//Tape::~Tape()
//{
//	delete &this->title;
//	delete &this->filmedAt;
//	delete &this->creationDate;
//	delete &this->footagePreview;
//	delete this;
//}

std::string Tape::getFilmedAt() const
{
	return this->filmedAt;
}

Date Tape::getCreationDate() const
{
	return this->creationDate;
}

std::string Tape::getFootagePreview() const
{
	return this->footagePreview;
}

bool operator==(const Tape& tape1, const Tape& tape2)
{
	return tape1.title == tape2.title;
}

std::istream& operator>>(std::istream& inputStream, Tape& tape)
{
	// TODO: insert return statement here

	std::string arguments;
	std::getline(inputStream, arguments);

	std::string argument;
	std::string formatedArguments;
	std::stringstream stringStream(arguments);
	while (std::getline(stringStream, argument, ','))
	{
		formatedArguments += (argument + " ");
	}
	//formatedArguments = formatedArguments.substr(0, formatedArguments.size() - 2);
	//std::cout << formatedArguments << '\n';
	std::stringstream tapeStream(formatedArguments);
	tapeStream >> tape.title >> tape.filmedAt >> tape.creationDate >> tape.accessCount >> tape.footagePreview;
	return inputStream;
}

std::ostream& operator<<(std::ostream& outputStream, const Tape& tape)
{
	// TODO: insert return statement here
	outputStream << tape.getTitle() << "," << tape.getFilmedAt() << "," << tape.getCreationDate() << "," << tape.getAccessCount() << "," << tape.getFootagePreview();
	return outputStream;
}
