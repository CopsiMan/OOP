#pragma once

#include "Tape.h"

//typedef void* TElement;
typedef Tape* TElement;

class DynamicArray
{
	TElement* elements;
	int capacity;
	int size;

	void resize();

public:
	DynamicArray(int capacity = 8);
	void add(TElement element);

	// returns an index of an element , -1 if not found
	int getIndex(TElement element);
	TElement getElement(int position);
	void remove(int position);
	int getSize() const;
	TElement* getElements();
	~DynamicArray();
};

