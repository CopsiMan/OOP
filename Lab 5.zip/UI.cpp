#include "UI.h"

void UI::Start()
{
	Service service{};
	string userMode, userCommand;
	getline(cin, userMode);
	if (userMode == "mode A")
		this->adminMode = true;
	else
		this->adminMode = false;

	getline(cin, userCommand);
	while (userCommand != "exit")
	{
		string* arguments = service.parseInput(userCommand);
		try {

			if (this->adminMode == true) {
				if (userCommand.find("add", 0) == 0) {
					service.add(arguments);
				}
				else if (userCommand.find("delete", 0) == 0) {
					service.remove(arguments);
				}
				else if (userCommand.find("update", 0) == 0) {
					service.update(arguments);
				}
				else if (userCommand.find("list", 0) == 0) {
					Tape** tapes = service.getAll();
					int length = service.size();
					for (int i = 0; i < length; i++)
						cout << tapes[i]->getTitle() << ' ' << tapes[i]->getFilmedAt() << ' ' << tapes[i]->getCreationDate() << ' ' << tapes[i]->getAccessCount() << ' ' << tapes[i]->getFootagePreview() << ' ' << endl;
				}
			}
		}
		catch (const char* exception) {
			cout << exception << endl;
		}
		delete[] arguments;
		getline(cin, userCommand);

	}
}
