#pragma once

#include "Tape.h"
#include "DynamicArray.h"

//typedef Tape TElement;

class Repository
{
private:
	DynamicArray dynamicArray{};

public:
	Repository();
	void add(TElement element);
	void remove(TElement element);
	void update(TElement newTElement);
	TElement* getAll();
	int size();
};

