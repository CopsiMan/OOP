#include "UI.h"

/*

random ui test:

fileLocation save+mylist+html.csv
mylistLocation save+mylist+html.html
mode A
add 123, abc, 01-01-2000, 456, def
mode B
mode B
save 123
mode A
add 1223, abc, 01-01-2000, 456, def
mode B
save 1223
mylist


fileLocation save+mylist+html.txt
mylistLocation save+mylist+html.html
mode A
add 123, abc, 01-01-2000, 456, def
mode B
mode B
save 123
mylist
exit


fileLocation save+mylist+csv.txt
mylistLocation save+mylist+csv.csv
mode A
add 123, abc, 01-01-2000, 456, def
mode B
mode B
save 123
mylist
exit

fileLocation D:\Facultate\Semestrul 2\OOP\Lab 8\tapes.txt
mode A
add 100, abc, 01-01-2010, 123, zzz
add 200, def, 01-01-2010, 123, zzz
add 300, abc, 01-01-2000, 456, zzz
add 400, def, 01-01-2000, 456, zzz
mode B
list abc, 300
exit


fileLocation D:\Facultate\Semestrul 2\OOP\Lab 8\tapes.txt
mode A
add 123, abc, 01-01-2000, 456, def
list

Examples :
mode A
add 100, abc, 01-01-2010, 123, zzz
add 200, def, 01-01-2010, 123, zzz
add 300, abc, 01-01-2000, 456, zzz
add 400, def, 01-01-2000, 456, zzz
mode B
list abc, 300
exit


mode A
add 123, abc, 01-01-2000, 456, def
list

mode A
add 123, abc, 01-01-2000, 456, def
mode B
next
exit 

fileLocation D:\Facultate\Semestrul 2\OOP\Lab 8\tapes.txt
mode A
add 123, abc, 01-01-2000, 456, def
mode B
save 123
mylist
exit

*/

void UI::Start()
{
	//Service service{};
	std::string userMode, userCommand;
	//getline(cin, userMode);

	std::getline(std::cin, userCommand);
	while (userCommand != "exit")
	{
		std::string* arguments = this->parseInput(userCommand);
		try {

			if (userCommand == "mode A")
				this->adminMode = true;
			else if (userCommand == "mode B")
				this->adminMode = false;

			if (userCommand.find("fileLocation", 0) == 0) {
				string filePath = userCommand.substr(userCommand.find(" ") + 1);

				// replace(filePath.begin(), filePath.end(), '\\', '/');

				ofstream file(filePath);
				file.close();
				service.setPath(filePath);

				/*
				//cout << filePath << endl;
				ofstream file(filePath);
				file << Tape{ "123", "abc", Date{ 13 , 1 , 2019 }, 456, "def" };*/
			}
			else if (userCommand.find("mylistLocation", 0) == 0) {
				string myListPath = userCommand.substr(userCommand.find(" ") + 1);

				// replace(filePath.begin(), filePath.end(), '\\', '/');

				ofstream file(myListPath);
				file.close();
				service.setMyListPath(myListPath);

				/*
				//cout << filePath << endl;
				ofstream file(filePath);
				file << Tape{ "123", "abc", Date{ 13 , 1 , 2019 }, 456, "def" };*/
			}
			else if (this->adminMode == true) {
				if (userCommand.find("add", 0) == 0) {
					std::string title = arguments[TITLE];
					std::string filmedAt = arguments[FILMED_AT];
					vector<string> date = this->splitString(arguments[CREATION_DATE], '-');
					Date creationDate{ stoi(date[DAY]),stoi(date[MONTH]),stoi(date[YEAR]) };
					int accessCount = std::stoi(arguments[ACCES_COUNT]);
					std::string footagePreview = arguments[FOOTAGE_PREVIEW];
					service.add(title, filmedAt, creationDate, accessCount, footagePreview);
				}
				else if (userCommand.find("delete", 0) == 0) {
					std::string title = arguments[TITLE];
					service.remove(title);
				}
				else if (userCommand.find("update", 0) == 0) {
					std::string title = arguments[TITLE];
					std::string filmedAt = arguments[FILMED_AT];
					vector<string> date = this->splitString(arguments[CREATION_DATE], '-');
					Date creationDate{ stoi(date[DAY]),stoi(date[MONTH]),stoi(date[YEAR]) };
					int accessCount = std::stoi(arguments[ACCES_COUNT]);
					std::string footagePreview = arguments[FOOTAGE_PREVIEW];
					service.update(title, filmedAt, creationDate, accessCount, footagePreview);
				}
				else if (userCommand.find("list", 0) == 0) {
					std::vector<Tape*> tapes = service.getAll();
					//int length = service.size();
					for (const Tape* tape : tapes) {
						cout << *tape << endl;
						delete tape;
					}
					/*for (int i = 0; i < length; i++)
						cout << *tapes[i] << endl;*/
					//std::cout << tapes[i]->getTitle() << ' ' << tapes[i]->getFilmedAt() << ' ' << tapes[i]->getCreationDate() << ' ' << tapes[i]->getAccessCount() << ' ' << tapes[i]->getFootagePreview()  << std::endl;
				}
			}
			else {
				if (userCommand.find("list", 0) == 0) {
					std::string filmedAt = arguments[LIST_FILMED_AT];
					int maximumAccesCount = std::stoi(arguments[LIST_ACCES_COUNT]);
					std::vector<Tape*> tapes = service.getAll();
					std::vector<Tape*> tapesToPrint;
					//std::vector<Tape*> tapesToPrint(tapes.size());
					copy_if(tapes.begin(), tapes.end(), back_inserter(tapesToPrint), [filmedAt, maximumAccesCount](Tape* tape) {
						return filmedAt == tape->getFilmedAt() && maximumAccesCount > tape->getAccessCount();
						});
					for (const Tape* tape : tapesToPrint)
							cout << *tape << endl;
					for (const Tape* tape : tapes) {
						delete tape;
					}
					//int length = service.size();
					//for (int i = 0; i < length; i++);
					//if (filmedAt == tapes[i]->getFilmedAt() && maximumAccesCount > tapes[i]->getAccessCount())
						// std::cout << tapes[i]->getTitle() << ' ' << tapes[i]->getFilmedAt() << ' ' << tapes[i]->getCreationDate() << ' ' << tapes[i]->getAccessCount() << ' ' << tapes[i]->getFootagePreview()  << std::endl;
				}
				else if (userCommand.find("next", 0) == 0) {
					Tape tape = *service.nextElement();
					// std::cout << tape.getTitle() << ' ' << tape.getFilmedAt() << ' ' << tape.getCreationDate() << ' ' << tape.getAccessCount() << ' ' << tape.getFootagePreview() << ' ' << std::endl;
				}
				else if (userCommand.find("save", 0) == 0) {
					std::string title = arguments[TITLE];
					service.saveToFieldAgentRepository(title);
				}
				else if (userCommand.find("mylist", 0) == 0) {
					vector<Tape*> tapes{ service.getAllFromFieldAgentRepository() };
					for (Tape* tape : tapes){
						cout << *tape << endl;
						delete tape;
					}
					system(service.getFieldAgentPath().c_str());

					/*Tape** tapes = service.getAllFromFieldAgentRepository();
					int length = service.sizeOfFieldAgentRepository();
					for (int i = 0; i < length; i++)
						cout << *tapes[i] << endl;*/
					// std::cout << tapes[i]->getTitle() << ' ' << tapes[i]->getFilmedAt() << ' ' << tapes[i]->getCreationDate() << ' ' << tapes[i]->getAccessCount() << ' ' << tapes[i]->getFootagePreview() << std::endl;
				}
			}
		}
		catch (const char* exception) {
			std::cout << exception << std::endl;
		}
		catch (const FileRepository_Exception& exception) {
			cout << exception.what() << endl;
		}
		catch (const Tape_Exception& exception) {
			cout << exception.what() << endl;
		}
		delete[] arguments;
		std::getline(std::cin, userCommand);

	}
}

std::string* UI::parseInput(std::string userCommand)
{
	std::string* arguments = new std::string[MAX_ARGUMENTS];
	std::string delimiter = ", ";
	int argument_index = 0;
	int positionInString = 0;
	//cout << userCommand << endl;

	// removing the first part of the user input so only the arguments remain
	userCommand = userCommand.substr(userCommand.find(" ", 0) + 1, userCommand.size());

	// this is basically a strtok for std::string 
	while ((positionInString = userCommand.find(delimiter)) != std::string::npos) {
		arguments[argument_index++] = userCommand.substr(0, positionInString);
		userCommand.erase(0, positionInString + delimiter.length());
		// cout << arguments[argument_index - 1] << endl;
	}
	arguments[argument_index++] = userCommand;
	return arguments;

	/*for (int i = 0; i < argument_index; i++)
		cout << arguments[i] << endl;*/
}

vector<string> UI::splitString(string stringToSplit, char delimiter)
{
	vector <string> result;
	stringstream stringStream(stringToSplit);
	string token;
	while (getline(stringStream, token, delimiter))
		result.push_back(token);

	return result;
}	
