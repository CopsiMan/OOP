#include "UI.h"

/*
Examples :
mode A
add 100, abc, 01-01-2010, 123, zzz
add 200, def, 01-01-2010, 123, zzz
add 300, abc, 01-01-2000, 456, zzz
add 400, def, 01-01-2000, 456, zzz
mode B
list abc, 300
exit

mode A
add 123, abc, 01-01-2000, 456, def
mode B
next
exit

mode A
add 123, abc, 01-01-2000, 456, def
mode B
save 123
mylist
exit

*/

void UI::Start()
{
	Service service{};
	std::string userMode, userCommand;
	//getline(cin, userMode);

	std::getline(std::cin, userCommand);
	while (userCommand != "exit")
	{
		std::string* arguments = this->parseInput(userCommand);
		try {

			if (userCommand == "mode A")
				this->adminMode = true;
			else if (userCommand == "mode B")
				this->adminMode = false;

			if (this->adminMode == true) {
				if (userCommand.find("add", 0) == 0) {
					std::string title = arguments[TITLE];
					std::string filmedAt = arguments[FILMED_AT];
					std::string creationDate = arguments[CREATION_DATE];
					int accessCount = std::stoi(arguments[ACCES_COUNT]);
					std::string footagePreview = arguments[FOOTAGE_PREVIEW];
					service.add(title, filmedAt, creationDate, accessCount, footagePreview);
				}
				else if (userCommand.find("delete", 0) == 0) {
					std::string title = arguments[TITLE];
					service.remove(title);
				}
				else if (userCommand.find("update", 0) == 0) {
					std::string title = arguments[TITLE];
					std::string filmedAt = arguments[FILMED_AT];
					std::string creationDate = arguments[CREATION_DATE];
					int accessCount = std::stoi(arguments[ACCES_COUNT]);
					std::string footagePreview = arguments[FOOTAGE_PREVIEW];
					service.update(title, filmedAt, creationDate, accessCount, footagePreview);
				}
				else if (userCommand.find("list", 0) == 0) {
					Tape** tapes = service.getAll();
					int length = service.size();
					for (int i = 0; i < length; i++)
						std::cout << tapes[i]->getTitle() << ' ' << tapes[i]->getFilmedAt() << ' ' << tapes[i]->getCreationDate() << ' ' << tapes[i]->getAccessCount() << ' ' << tapes[i]->getFootagePreview()  << std::endl;
				}
			}
			else {
				if (userCommand.find("list", 0) == 0) {
					std::string filmedAt = arguments[FIRST_ARGUMENT];
					int maximumAccesCount = std::stoi(arguments[SECOND_ARGUMENT]);
					Tape** tapes = service.getAll();
					int length = service.size();
					for (int i = 0; i < length; i++)
						if (filmedAt == tapes[i]->getFilmedAt() && maximumAccesCount > tapes[i]->getAccessCount())
						std::cout << tapes[i]->getTitle() << ' ' << tapes[i]->getFilmedAt() << ' ' << tapes[i]->getCreationDate() << ' ' << tapes[i]->getAccessCount() << ' ' << tapes[i]->getFootagePreview()  << std::endl;
				}
				else if (userCommand.find("next", 0) == 0) {
					Tape tape = *service.next();
					std::cout << tape.getTitle() << ' ' << tape.getFilmedAt() << ' ' << tape.getCreationDate() << ' ' << tape.getAccessCount() << ' ' << tape.getFootagePreview() << ' ' << std::endl;
				}
				else if (userCommand.find("save", 0) == 0) {
					std::string title = arguments[TITLE];
					service.saveToBUserList(title);
				}
				else if (userCommand.find("mylist", 0) == 0) {
					Tape** tapes = service.getAllBUser();
					int length = service.sizeBUserList();
					for (int i = 0; i < length; i++)
						std::cout << tapes[i]->getTitle() << ' ' << tapes[i]->getFilmedAt() << ' ' << tapes[i]->getCreationDate() << ' ' << tapes[i]->getAccessCount() << ' ' << tapes[i]->getFootagePreview() << std::endl;
				}
			}
		}
		catch (const char* exception) {
			std::cout << exception << std::endl;
		}
		delete[] arguments;
		std::getline(std::cin, userCommand);

	}
}


std::string* UI::parseInput(std::string userCommand)
{
	std::string* arguments = new std::string[MAX_ARGUMENTS];
	std::string delimiter = ", ";
	int argument_index = 0;
	int positionInString = 0;
	//cout << userCommand << endl;

	// removing the first part of the user input so only the arguments remain
	userCommand = userCommand.substr(userCommand.find(" ", 0) + 1, userCommand.size());

	// this is basically a strtok for std::string 
	while ((positionInString = userCommand.find(delimiter)) != std::string::npos) {
		arguments[argument_index++] = userCommand.substr(0, positionInString);
		userCommand.erase(0, positionInString + delimiter.length());
		// cout << arguments[argument_index - 1] << endl;
	}
	arguments[argument_index++] = userCommand;
	return arguments;

	/*for (int i = 0; i < argument_index; i++)
		cout << arguments[i] << endl;*/
}