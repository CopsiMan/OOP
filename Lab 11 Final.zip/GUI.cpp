#include "GUI.h"

GUI::GUI(std::string path)
{
	this->service = new Service{ path, path };
	this->init();
	this->populateList();
	this->connectSignalsAndSlots();
}

void GUI::init()
{
	QVBoxLayout* mainLayout = new QVBoxLayout{ this };
	QVBoxLayout* tapesTabLayout = new QVBoxLayout{ this };
	this->chartTab = new QTabWidget{};

	this->tabs = new QTabWidget{};

	QTabWidget* tapesTab = new QTabWidget();
	this->tapesListWidget = new QListWidget{};
	tapesTabLayout->addWidget(this->tapesListWidget);

	this->titleLineEdit = new QLineEdit{};
	this->locationLineEdit = new QLineEdit{};
	this->dateLineEdit = new QLineEdit{};
	this->accessCountLineEdit = new QLineEdit{};
	this->previewLineEdit = new QLineEdit{};

	this->addButton = new QPushButton{"Add"};
	this->deleteButton = new QPushButton{"Delete"};
	this->updateButton = new QPushButton{"Update"};

	QFormLayout* tapesForm = new QFormLayout{};
	tapesForm->addRow("Title: ", this->titleLineEdit);
	tapesForm->addRow("Location: ", this->locationLineEdit);
	tapesForm->addRow("Date: ", this->dateLineEdit);
	tapesForm->addRow("Access Count: ", this->accessCountLineEdit);
	tapesForm->addRow("Footage Preview: ", this->previewLineEdit);

	tapesTabLayout->addLayout(tapesForm);

	QGridLayout* buttons = new QGridLayout{};
	buttons->addWidget(this->addButton, 0, 0);
	buttons->addWidget(this->deleteButton, 0, 1);
	buttons->addWidget(this->updateButton, 0, 2);

	tapesTabLayout->addLayout(buttons);


	tapesTab->setLayout(tapesTabLayout);
	tapesTab->setMinimumSize(QSize(400, 300));

	this->tabs->addTab(tapesTab, tr("Tapes"));



	this->tabs->addTab(this->chartTab, tr("Graph"));
	mainLayout->addWidget(this->tabs);
}

void GUI::populateList()
{
	this->tapesListWidget->clear();

	std::vector<TElement> tapes = this->service->getAll();
	for (TElement tape : tapes) {
		this->tapesListWidget->addItem(QString::fromStdString(tape->toString()));
		delete tape;
	}
	this->drawChart();
}

void GUI::drawChart()
{
	QChart* chart = new QChart{ };
	QBarSet* tapesAccessCount = new QBarSet("Tape access count");
	std::vector<TElement> tapes = this->service->getAll();
	std::sort(tapes.begin(), tapes.end(), [](TElement first, TElement second) {return first->getAccessCount() > second->getAccessCount(); });
	// *tapesAccessCount << 1 << 2 << 3 << 4 << 5 << 6;
	int maximumAccessCount = 0;
	for (TElement tape : tapes) {
		int accessCount = tape->getAccessCount();
		if (accessCount > maximumAccessCount)
			maximumAccessCount = accessCount;
		*tapesAccessCount << accessCount;
	}

	QPen pen(QRgb(0xfdb157));
	pen.setWidth(5);
	QLinearGradient backgroundGradient;
	backgroundGradient.setStart(QPointF(0, 0));
	backgroundGradient.setFinalStop(QPointF(0, 1));
	backgroundGradient.setColorAt(0.0, QRgb(0xdc143c));
	backgroundGradient.setColorAt(1.0, QRgb(0x512888));
	/*
	backgroundGradient.setColorAt(0.0, QRgb(0xdc143c));
	backgroundGradient.setColorAt(0.5, QRgb(0xffffff));
	backgroundGradient.setColorAt(1.0, QRgb(0x00ff00));
	*/
	backgroundGradient.setCoordinateMode(QGradient::ObjectBoundingMode);
	// series->barSets->brush(backgroundGradient);
	tapesAccessCount->setBrush(backgroundGradient);

	QBarSeries* series = new QBarSeries(); 
	/*
	series->remove(tapesAccessCount);
	series->append(tapesAccessCount);*/
	series->append(tapesAccessCount);  

	chart->removeSeries(series);
	chart->addSeries(series);
	chart->setTitle("Tapes acces count bar chart");
	chart->setAnimationOptions(QChart::SeriesAnimations);


	QStringList* tapesTitles = new QStringList{};
	//tapesTitles << "Jan" << "Feb" << "Mar" << "Apr" << "May" << "Jun";
	for (TElement tape : tapes) {
		*tapesTitles << tape->getTitle().c_str();
		delete tape;
	}

	QBarCategoryAxis* axisX = new QBarCategoryAxis();
	axisX->append(*tapesTitles);
	chart->addAxis(axisX, Qt::AlignBottom);
	series->attachAxis(axisX);

	QValueAxis* axisY = new QValueAxis();
	axisY->setRange(0, maximumAccessCount + 10);
	chart->addAxis(axisY, Qt::AlignLeft);
	series->attachAxis(axisY);

	chart->legend()->setVisible(true);
	chart->legend()->setAlignment(Qt::AlignBottom);

	QChartView* chartView = new QChartView();
	chartView->setChart(chart);
	chartView->setRenderHint(QPainter::Antialiasing);

	QLayout* chartLayout = new QVBoxLayout{};
	chartLayout->addWidget(chartView);
	this->chartTab->setLayout(chartLayout);
	this->chartTab->updateGeometry();
}

int GUI::getSelectedIndex()
{
	QModelIndexList selectedIndexes = this->tapesListWidget->selectionModel()->selectedIndexes();
	if (selectedIndexes.size() == 0) {
		this->titleLineEdit->clear();
		this->locationLineEdit->clear();
		this->dateLineEdit->clear();
		this->accessCountLineEdit->clear();
		this->previewLineEdit->clear();
		return -1;
	}

	int selectedIndex = selectedIndexes.at(0).row();

	return selectedIndex;
}

void GUI::connectSignalsAndSlots()
{
	QObject::connect(this->tapesListWidget, &QListWidget::itemSelectionChanged, [this]() {
		int selectedIndex = this->getSelectedIndex();
		if (selectedIndex < 0)
			return;
		std::vector<TElement> selectedELements = this->service->getAll();
		TElement selectedELement = selectedELements[selectedIndex];
		this->titleLineEdit->setText(QString::fromStdString(selectedELement->getTitle()));
		this->locationLineEdit->setText(QString::fromStdString(selectedELement->getFilmedAt()));
		this->dateLineEdit->setText(QString::fromStdString(selectedELement->getCreationDate().toString()));
		this->accessCountLineEdit->setText(QString::fromStdString(std::to_string(selectedELement->getAccessCount())));
		this->previewLineEdit->setText(QString::fromStdString(selectedELement->getFootagePreview()));
		for (TElement element : selectedELements)
			delete element;
		});

	QObject::connect(this->addButton, &QPushButton::clicked, this,  &GUI::add);
	QObject::connect(this->deleteButton, &QPushButton::clicked, this,  &GUI::destroy);
	QObject::connect(this->updateButton, &QPushButton::clicked, this,  &GUI::update);
}

void GUI::add()
{
	try {
		vector<string> date = this->splitString(this->dateLineEdit->text().toStdString(), '-');
		Date creationDate{ stoi(date[DAY]),stoi(date[MONTH]),stoi(date[YEAR]) };
		this->service->add(
			this->titleLineEdit->text().toStdString(),
			this->locationLineEdit->text().toStdString(),
			creationDate,
			stoi(this->accessCountLineEdit->text().toStdString()),
			this->previewLineEdit->text().toStdString()
		);
		this->populateList();
	}
	catch (exception& ex) {
		QMessageBox::critical(this, "Error", ex.what());
	}
}

void GUI::destroy()
{
	try {
		this->service->remove(
			this->titleLineEdit->text().toStdString()
		);
		this->populateList();
	}
	catch (exception& ex) {
		QMessageBox::critical(this, "Error", ex.what());
	}
}

void GUI::update()
{
	try {
		vector<string> date = this->splitString(this->dateLineEdit->text().toStdString(), '-');
		Date creationDate{ stoi(date[DAY]),stoi(date[MONTH]),stoi(date[YEAR]) };
		this->service->update(
			this->titleLineEdit->text().toStdString(),
			this->locationLineEdit->text().toStdString(),
			creationDate,
			stoi(this->accessCountLineEdit->text().toStdString()),
			this->previewLineEdit->text().toStdString()
		);
		this->populateList();
	}
	catch (exception& ex) {
		QMessageBox::critical(this, "Error", ex.what());
	}
}


std::vector<std::string> GUI::splitString(std::string stringToSplit, char delimiter)
{
	vector <string> result;
	stringstream stringStream(stringToSplit);
	string token;
	while (getline(stringStream, token, delimiter))
		result.push_back(token);

	return result;
}
