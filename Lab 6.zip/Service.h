#pragma once

#include "Repository.h"
#include <string.h>

#define MAX_ARGUMENTS 5
#define TITLE 0
#define FILMED_AT 1
#define CREATION_DATE 2
#define ACCES_COUNT 3
#define FOOTAGE_PREVIEW 4

class Service
{
private:
	Repository repository{};
	Repository bUserRepo{};
	int bUserIndex;

public:
	//std::string* parseInput(std::string userCommand);
	Service();
	void add(std::string title, std::string filmedAt, std::string creationDate, int accessCount, std::string footagePreview);
	void remove(std::string title);
	void update(std::string title, std::string filmedAt, std::string creationDate, int accessCount, std::string footagePreview);
	TElement* getAll();
	int size();
	TElement next();
	void saveToBUserList(std::string title);
	TElement* getAllBUser();
	int sizeBUserList();
};

