#pragma once

#include <string>

class Tape
{
private:
	std::string title, filmedAt, creationDate, footagePreview;
	int accessCount;

public:
	Tape(std::string title = "-", std::string filmedAt = "-", std::string creationDate = "-", int accessCount = 0, std::string footagePreview = "-");
	std::string getTitle() const;
	std::string getFilmedAt() const;
	std::string getCreationDate() const;
	std::string getFootagePreview() const;
	int getAccessCount() const;
	std::string setTitle(std::string title);
	std::string setFilmedAt(std::string filmedAt);
	std::string setCreationDate(std::string creationDate);
	std::string setFootagePreview(std::string footagePreview);
	int setAccessCount(int accessCount);
	Tape& operator=(const Tape& tape);
	friend bool operator==(const Tape& tape1, const Tape& tape2);
	//~Tape();
};

bool operator==(const Tape& tape1, const Tape& tape2);