//#include "Test.h"
//#include "DynamicArray.h"
//#include "MemoryRepository.h"
//#include "Service.h"
//#include "Date.h"
//
//#include <assert.h>
//#include <iostream>
//#include <algorithm>
//#include <fstream>
//
//using namespace std;
//
//void test_getTitle_validInput_tapeCreated() {
//	Date date{ 29 , 2 , 2020 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	//cout << tape.getTitle();
//	assert(tape.getTitle() == "F1423");
//}
//
//void test_getFilmetAt_validInput_tapeCreated() {
//	Date date{ 13 , 1 , 2001 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	assert(tape.getFilmedAt() == "restaurant exterior");
//}
//void test_getCreationDate_validInput_tapeCreated() {
//	Date date{ 13 , 1 , 1900 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	assert(tape.getCreationDate() == date);
//}
//void test_getAccessCount_validInput_tapeCreated() {
//	Date date{ 13 , 1 , 2019 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	assert(tape.getAccessCount() == 7);
//}
//void test_getFootagePreview_validInput_tapeCreated() {
//	Date date{ 13 , 1 , 2019 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	assert(tape.getFootagePreview() == "prev8.mp4");
//}
//
//void test_setTitle_validInput_titleSet() {
//	Date date{ 13 , 1 , 2019 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	tape.setTitle("F14231");
//	assert(tape.getTitle() == "F14231");
//}
//
//void test_setFilmedAt_validInput_filmedAtSet() {
//	Date date{ 13 , 1 , 2019 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	tape.setFilmedAt("restaurant exterior1");
//	assert(tape.getFilmedAt() == "restaurant exterior1");
//}
//void test_setCreationDate_validInput_creationDateSet() {
//	Date date{ 13 , 1 , 2019 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	Date otherDate{ 13 , 1 , 2019 };
//	tape.setCreationDate(otherDate);
//	assert(tape.getCreationDate() == otherDate);
//}
//void test_setAccessCount_validInput_accessCountSet() {
//	Date date{ 13 , 1 , 2019 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	tape.setAccessCount(8);
//	assert(tape.getAccessCount() == 8);
//}
//void test_setFootagePreview_validInput_footagePreviewSet() {
//	Date date{ 13 , 1 , 2019 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	tape.setFootagePreview("prev8.mp41");
//	assert(tape.getFootagePreview() == "prev8.mp41");
//}
//
//void test_setTitle_invalidInput_ThrowsException() {
//	Date date{ 13 , 1 , 2019 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	try {
//		tape.setTitle("");
//		assert(false);
//	}
//	catch (const Tape_Exception& exception) {
//		//cout << exception.what() << endl;
//		assert(true);
//	}
//}
//
//void test_setFilmetAt_invalidInput_ThrowsException() {
//	Date date{ 13 , 1 , 2019 };
//	date.setMonth(2);
//	Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	try {
//		tape.setFilmedAt("");
//		assert(false);
//	}
//	catch (const Tape_Exception& exception) {
//		assert(true);
//	}
//}
//void test_setCreationDate_invalidInput_ThrowsException() {
//	Date date{ 13 , 1 , 2019 };
//	date.setYear(2000);
//	Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	Date badDate{ 13 , -1 , 2019 };
//	try {
//		tape.setCreationDate(badDate);
//		assert(false);
//	}
//	catch (const Tape_Exception& exception) {
//		assert(true);
//	}
//}
//void test_setAccessCount_invalidInput_ThrowsException() {
//	Date date{ 13 , 1 , 2019 }; 
//	date.setDay(2);
//	Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	try {
//		tape.setAccessCount(-3);
//		assert(false);
//	}
//	catch (const Tape_Exception& exception) {
//		assert(true);
//	}
//}
//void test_setFootagePreview_invalidInput_ThrowsException() {
//	Date date{ 13 , 1 , 2019 }; Tape tape{ "F1423", "restaurant exterior", date, 7, "prev8.mp4" };
//	try {
//		tape.setFootagePreview("");
//		assert(false);
//	}
//	catch (const Tape_Exception& exception) {
//		assert(true);
//	}
//}
//
//
//void test_createDate_invalidDay_ThrowsException() {
//	try {
//		Date date{ 43,3,2000 };
//		Tape tape{ "-","-",date };
//		assert(false);
//	}
//	catch (const Tape_Exception & exception) {
//		assert(true);
//	}
//}
//
//void test_createDate_invalifMonth_ThrowsException() {
//	try {
//		Date date{ 13,13,2000 };
//		Tape tape{ "-","-",date };
//		assert(false);
//	}
//	catch (const Tape_Exception & exception) {
//		assert(true);
//	}
//}
//void test_createDate_invalidYear_ThrowsException() {
//	try {
//		Date date{ 1,1,3000 };
//		Tape tape{ "-","-",date };
//		assert(false);
//	}
//	catch (const Tape_Exception & exception) {
//		assert(true);
//	}
//}
//
//void test_addDynamicArray_validInput_ElementAdded() {
//	DynamicArray<Tape*> dynamicArray{};
//	Tape* tape = new Tape{};
//	dynamicArray.add(tape);
//	assert(dynamicArray.getSize() == 1);
//	//delete a;
//}
//
//void test_removeDynamicArray_validInput_ElementRemoved() {
//	DynamicArray<Tape*> dynamicArray{};
//	Tape* tape1 = new Tape{};
//	Tape* tape2 = new Tape{};
//	int firstPosition = 0;
//	dynamicArray.add(tape1);
//	dynamicArray.add(tape2);
//	dynamicArray.remove(firstPosition);
//	assert(dynamicArray.getSize() == 1);
//	//delete a;
//}
//
//void test_getIndexDynamicArray_ReturnedIndex() {
//	DynamicArray<Tape*> dynamicArray{};
//	Tape* tape = new Tape{};
//	int firstPosition = 0;
//	dynamicArray.add(tape);
//	assert(dynamicArray.getIndex(tape) == firstPosition);
//}
//
//void test_getElementDynamicArray_ReturnedElement() {
//	DynamicArray<Tape*> dynamicArray{};
//	Tape* tape = new Tape{};
//	dynamicArray.add(tape);
//	assert(*dynamicArray.getElement(dynamicArray.getIndex(tape)) == *tape);
//}
//
//void test_getSizeDynamicArray_ReturnedSize() {
//	DynamicArray<Tape*> dynamicArray{};
//	Tape* tape = new Tape{};
//	dynamicArray.add(tape);
//	assert(dynamicArray.getSize() == 1);
//}
//
//void test_increaseCapacityDynamicArray_DoublesTheCapacity() {
//	DynamicArray<Tape*> dynamicArray{ 1 };
//	Tape* tape = new Tape{};
//	dynamicArray.add(tape);
//	Tape* tape1 = new Tape{};
//	dynamicArray.add(tape1);
//}
//
//void test_getElementsDynamicArray_ReturnedElements() {
//	DynamicArray<Tape*> dynamicArray{ 1 };
//	Tape* tape = new Tape{"!23"};
//	dynamicArray.add(tape);
//	Tape* tape1 = new Tape{"12321"};
//	dynamicArray.add(tape1);
//	Tape** tapes = dynamicArray.getElements();
//	assert(*tapes[0] == *tape && *tapes[1] == *tape1); // && tapes[1] == tape1);
//}
//
//void test_removeDynamicArray_invalidInput_ThrowsException() {
//	DynamicArray<Tape*> dynamicArray{};
//	// this is an invalid position
//	int position = 1;
//	try{
//		dynamicArray.remove(position);
//		assert(false);
//	}
//	catch (const char* exception) {
//		assert(true);
//	}
//}
//
//void test_getIndexDynamicArray_invalidInput_ReturnsMinusOne() {
//	DynamicArray<Tape*> dynamicArray{};
//	Tape* tape = new Tape{};
//	assert(dynamicArray.getIndex(tape) == -1);
//	delete tape;
//}
//
//void test_getElementDynamicArray_invalidInput_ThrowsException() {
//	DynamicArray<Tape*> dynamicArray{};
//	int invalidPosition = 3;
//	try {
//		dynamicArray.getElement(invalidPosition);
//		assert(false);
//	}
//	catch (const char* exception) {
//		assert(true);
//	}
//}
//
//void test_writeToFile_validInput_wroteToFile() {
//	Tape tape{ "F1423", "restaurant exterior", Date{}, 7, "prev8.mp4" };
//	string path = "D:/Facultate/Semestrul 2/OOP/Lab 8/testWriteTape.txt";
//	/*cout << path << endl;
//	replace(path.begin(), path.end(), '/', '/');
//	cout << path << endl;*/
//	ofstream file(path);
//	if (!file.is_open())
//		assert(false);
//	file << tape << endl;
//	file << tape << endl;
//	file.close();
//}
//
//void test_readFromFile_validInput_readFromFile() {
//	string path = "D:/Facultate/Semestrul 2/OOP/Lab 8/readTape.txt";
//	ifstream file(path);
//	Tape tape{};
//	if (!file.is_open())
//		assert(false);
//	while (file >> tape);
//		// cout << tape << endl;
//	//assert(tape.getTitle() == "123");
//	assert(tape.getCreationDate().toString() == "1-13-2019");
//	file.close();
//}
//
//void Test_Tape() {
//	test_writeToFile_validInput_wroteToFile();
//	test_readFromFile_validInput_readFromFile();
//	test_getTitle_validInput_tapeCreated();
//	test_getFilmetAt_validInput_tapeCreated();
//	test_getCreationDate_validInput_tapeCreated();
//	test_getAccessCount_validInput_tapeCreated();
//	test_getFootagePreview_validInput_tapeCreated();
//	test_setTitle_validInput_titleSet();
//	test_setFilmedAt_validInput_filmedAtSet();
//	test_setCreationDate_validInput_creationDateSet();
//	test_setAccessCount_validInput_accessCountSet();
//	test_setFootagePreview_validInput_footagePreviewSet();;
//	test_setTitle_invalidInput_ThrowsException();
//	test_setFilmetAt_invalidInput_ThrowsException();
//	test_setCreationDate_invalidInput_ThrowsException();
//	test_setAccessCount_invalidInput_ThrowsException();
//	test_setFootagePreview_invalidInput_ThrowsException();
//	test_createDate_invalifMonth_ThrowsException();
//	test_createDate_invalidYear_ThrowsException();
//	test_createDate_invalidDay_ThrowsException();
//}
//
//void Test_DynamicArray()
//{
//	test_addDynamicArray_validInput_ElementAdded();
//	test_removeDynamicArray_validInput_ElementRemoved();
//	test_getIndexDynamicArray_ReturnedIndex();
//	test_getElementDynamicArray_ReturnedElement();
//	test_getSizeDynamicArray_ReturnedSize();
//	test_increaseCapacityDynamicArray_DoublesTheCapacity();
//	test_getElementsDynamicArray_ReturnedElements();
//	test_removeDynamicArray_invalidInput_ThrowsException();
//	test_getIndexDynamicArray_invalidInput_ReturnsMinusOne();
//	test_getElementDynamicArray_invalidInput_ThrowsException();
//}
//
//void test_addToRepository_validInput_ElementAdded() {
//	MemoryRepository repository{};
//	// repository.setPath("memoryRepo.txt");
//	Tape* tape = new Tape{};
//	repository.add(tape);
//	assert(repository.size() == 1);
//}
//
//void test_addToRepository_invalidInput_returnsException() {
//	MemoryRepository repository{};
//	Tape* tape = new Tape{};
//	//repository.setPath("memoryRepo.csv");
//	repository.add(tape);
//	Tape* tape1 = new Tape{};
//	try {
//		repository.add(tape1);
//		assert(false);
//	}
//	catch (const char* exception) {
//		assert(true);
//	}
//}
//void test_removeFromRepository_validInput_ElementRemoved() {
//	MemoryRepository repository{};
//	Tape* tape = new Tape{};
//	repository.add(tape);
//	repository.remove(tape);
//	assert(repository.size() == 0);
//}
//
//void test_removeFromRepository_invalidInput_returnsException() {
//	MemoryRepository repository{};
//	Tape* tape = new Tape{ "sad" };
//	repository.add(tape);
//	Tape* tape1 = new Tape{};
//	try {
//		repository.remove(tape1);
//		assert(false);
//	}
//	catch (const char* exception) {
//		assert(true);
//	}
//}
//void test_updateFromRepository_validInput_ElementUpdated() {
//	MemoryRepository repository{};
//	Tape* tape = new Tape{ "asd" };
//	repository.add(tape);
//	Tape* tape1 = new Tape{"asd","asdasd"};
//	Tape tape2{ "asd","asdasd" };
//	repository.update(tape1);
//	assert(*repository.getAll()[0] == tape2);
//}
//
//void test_updateFromRepository_invalidInput_returnsException() {
//	MemoryRepository repository{};
//	Tape* tape = new Tape{ "sad" };
//	repository.add(tape);
//	Tape* tape1 = new Tape{};
//	try {
//		repository.update(tape1);
//		assert(false);
//	}
//	catch (const char* exception) {
//		assert(true);
//	}
//}
//
//void test_addToService_validInput_ElementAdded(){
//	Service service{};
//	/* */
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	assert(service.size() == 1);
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//}
//void test_addToService_invalidInput_returnsException(){
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	// std::string arguments[] = { "123", "abc", Date{ 13 , 1 , 2019 }, "456", "def" };
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	try {
//		service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//		assert(false);
//	}
//	catch (const FileRepository_Exception & exception) {
//		assert(true);
//	}
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//}
//void test_removeFromService_validInput_ElementRemoved(){
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	service.setMyListPath("mylist.html");
//	// std::string arguments[] = { "123", "abc", Date{ 13 , 1 , 2019 }, "456", "def" };
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	service.remove("123");
//	assert(service.size() == 0);
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//}
//void test_removeFromService_invalidInput_returnsException(){
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	// std::string arguments[] = { "123", "abc", Date{ 13 , 1 , 2019 }, "456", "def" };
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	// arguments[0] = "12312";
//	try {
//		service.remove("12312");
//		assert(false);
//	}
//	catch (const FileRepository_Exception & exception) {
//		assert(true);
//	}
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//}
//void test_updateFromService_validInput_ElementUpdated(){
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	// std::string arguments[] = { "123", "abc", Date{ 13 , 1 , 2019 }, "456", "def" };
//	// std::string arguments1[] = { "123", "ab2c", "021 - 01 - 20200", "4526", "d2ef" };
//	Tape tape{ "123", "ab2c", Date{ 021 ,01 ,2010 }, 4526, "d2ef" };
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	service.update("123", "ab2c", Date{ 021 ,01 ,2010 }, 4526, "d2ef");
//	vector<Tape*> allTapes = service.getAll();
//	assert(*allTapes[0] == tape);
//	for (auto& tape : allTapes)
//		delete tape;
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//}
//void test_updateFromService_invalidInput_returnsException(){
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	// std::string arguments[] = { "123", "abc", Date{ 13 , 1 , 2019 }, "456", "def" };
//	// std::string arguments1[] = { "1223", "ab2c", "021 - 01 - 20200", "4526", "d2ef" };
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	try {
//		service.update("1223", "ab2c", Date{ 021 ,01 ,2010 }, 4526, "d2ef");
//		assert(false);
//	}
//	catch (const FileRepository_Exception & exception) {
//		assert(true);
//	}
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//}
//
//void test_nextElement_ValidInput_CyclesThroughElements() {
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	service.add("124", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	delete service.nextElement();
//	delete service.nextElement();
//	Tape tape{ "123", "abc", Date{ 13 , 1 , 2019 }, 456, "def" };
//	Tape* nextTape = service.nextElement();
//	assert(*nextTape == tape);
//	delete nextTape;
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//}
//
//void test_saveToFieldAgentRepository_ValidInput_ElementAdded() {
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	service.saveToFieldAgentRepository("123");
//	assert(service.sizeOfFieldAgentRepository() == 1);
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//}
//
//void test_saveToFieldAgentRepository_DuplicateElement_ThrowsException() {
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	service.setMyListPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testServiceMyList.txt");
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	service.saveToFieldAgentRepository("123");
//	try {
//		service.saveToFieldAgentRepository("123");
//		assert(false);
//	}
//	catch (const FileRepository_Exception& exception) {
//		assert(true);
//	}
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//	ofstream file1("D:/Facultate/Semestrul 2/OOP/Lab 8/testServiceMyList.txt");
//	file1 << "";
//	file1.close();
//}
//
//void test_saveToFieldAgentRepository_NonexistentElement_ThrowsException() {
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	try {
//		service.saveToFieldAgentRepository("123");
//		assert(false);
//	}
//	catch (const FileRepository_Exception & exception) {
//		assert(true);
//	}
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//}
//
//void test_getElementFromRepository_validInput_ElementReturned() {
//	MemoryRepository repository{};
//	Tape* tape = new Tape{"title"};
//	repository.add(tape);
//	assert(*repository.getElement(0) == *tape);
//}
//void test_findElementFromRepository_validInput_ElementReturned() {
//	MemoryRepository repository{};
//	Tape* tape = new Tape{ "title" };
//	repository.add(tape);
//	assert(*repository.find(tape) == *tape);
//}
//
//void test_getPathFroMemoryRepository_validInput_pathReturned() {
//	//MemoryRepository repository{ "path.txt" };
//	//assert("path.txt" == repository.getPath());
//}
//
//void Test_MemoryRepository() {
//	test_addToRepository_validInput_ElementAdded();
//	test_addToRepository_invalidInput_returnsException();
//	test_removeFromRepository_validInput_ElementRemoved();
//	test_removeFromRepository_invalidInput_returnsException();
//	test_updateFromRepository_validInput_ElementUpdated();
//	test_updateFromRepository_invalidInput_returnsException();
//	test_getElementFromRepository_validInput_ElementReturned();
//	test_getPathFroMemoryRepository_validInput_pathReturned();
//	test_findElementFromRepository_validInput_ElementReturned();
//}
//
//void test_addToFileRepository_validInput_ElementAdded() {
//	FileRepository repository{};
//	// repository.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.html");
//	Tape* tape = new Tape{};
//	repository.add(tape);
//	assert(repository.size() == 1);
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.html");
//	file << "";
//	file.close();
//}
//
//void test_addToFileRepository_invalidInput_returnsException() {
//	FileRepository repository{ "D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.txt" };
//	Tape* tape = new Tape{};
//	repository.add(tape);
//	Tape* duplicateTape = new Tape{};
//	try {
//		repository.add(duplicateTape);
//		assert(false);
//	}
//	catch (const FileRepository_Exception & exception) {
//		assert(true);
//	}
//	// delete tape;
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.txt");
//	file << "";
//	file.close();
//}
//void test_removeFromFileRepository_validInput_ElementRemoved() {
//	FileRepository repository{"D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.html"};
//	Tape* tape = new Tape{};
//	repository.add(tape);
//	Tape* tapeToRemove = new Tape{};
//	repository.remove(tapeToRemove);
//	assert(repository.size() == 0);
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.html");
//	file << "";
//	file.close();
//}
//
//void test_removeFromFileRepository_invalidInput_returnsException() {
//	FileRepository repository{ "D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.txt" };
//	Tape* tape = new Tape{ "sad" };
//	repository.add(tape);
//	Tape* inexistentTape = new Tape{};
//	try {
//		repository.remove(inexistentTape);
//		assert(false);
//	}
//	catch (const FileRepository_Exception & exception) {
//		assert(true);
//	}
//	//delete tape1;
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.txt");
//	file << "";
//	file.close();
//}
//void test_updateFromFileRepository_validInput_ElementUpdated() {
//	FileRepository repository{ "D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.txt" };
//	Tape* addedTape = new Tape{ "asd" };
//	repository.add(addedTape);
//	Tape* updatedTape = new Tape{ "asd","asdasd" };
//	Tape tapeToCompare{ "asd","asdasd" };
//	repository.update(updatedTape);
//	vector<TElement> allTapes = repository.getAll();
//	assert(*allTapes[0] == tapeToCompare);
//	for (const TElement& tape : allTapes)
//		delete tape;
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.txt");
//	file << "";
//	file.close();
//}
//
//void test_updateFromFileRepository_invalidInput_returnsException() {
//	FileRepository repository{ "D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.txt" };
//	Tape* tapeToAdd = new Tape{ "sad" };
//	repository.add(tapeToAdd);
//	Tape* inexistentTape = new Tape{};
//	try {
//		repository.update(inexistentTape);
//		assert(false);
//	}
//	catch (const FileRepository_Exception & exception) {
//		assert(true);
//	}
//
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.txt");
//	file << "";
//	file.close();
//}
//
//void test_getElementFromFileRepository_validInput_ElementReturned() {
//	FileRepository repository{ "D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository1.html" };
//	Tape* tapeToAdd = new Tape{"asd"};
//	Tape* anotherTapeToAdd = new Tape{"2asd"};
//	repository.add(tapeToAdd);
//	repository.add(anotherTapeToAdd);
//	Tape tapeToCompare{ "asd" };
//	Tape* returnedElement = repository.getElement(0);
//	assert(*returnedElement == tapeToCompare);
//	delete returnedElement;
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository1.html");
//	file << "";
//	file.close();
//}
//
//void test_findElementFromFileRepository_validInput_ElementReturned() {
//	FileRepository repository{ "D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.html" };
//	Tape* tapeToAdd = new Tape{ "asd" };
//	repository.add(tapeToAdd);
//	Tape* tapeToFind = new Tape{ "asd" };
//
//	Tape* returnedElement = repository.find(tapeToFind);
//	Tape tapeToCompare { "asd" };
//	assert(*returnedElement == tapeToCompare);
//	delete returnedElement;
//
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.html");
//	file << "";
//	file.close();
//}
//
//void test_getPathFromFileRepository_validInput_pathReturned() {
//	FileRepository repository{ "path.txt" };
//	//assert("path.txt" == repository.getPath());
//}
//
//void Test_FileRepository() {
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testFileRepository.txt");
//	file << "";
//	file.close();
//	test_addToFileRepository_validInput_ElementAdded();
//	test_addToFileRepository_invalidInput_returnsException();
//	test_removeFromFileRepository_validInput_ElementRemoved();
//	test_removeFromFileRepository_invalidInput_returnsException();
//	test_updateFromFileRepository_validInput_ElementUpdated();
//	test_updateFromFileRepository_invalidInput_returnsException();
//	test_getElementFromFileRepository_validInput_ElementReturned();
//	test_getPathFromFileRepository_validInput_pathReturned();
//	test_findElementFromFileRepository_validInput_ElementReturned();
//	/*
//	*/
//}
//
//void test_getPathFromService_validInput_pathReturned() {
//	Service service{};
//	service.setMyListPath("myListPath.txt");
//	assert(service.getFieldAgentPath() == "myListPath.txt");
//}
//
//void test_getAllFromFieldAgentRepository_validInput_RerunsElements() {
//
//	Service service{};
//	service.setPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.csv");
//	service.setMyListPath("D:/Facultate/Semestrul 2/OOP/Lab 8/testServiceMyList.csv");
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.csv");
//	file << "";
//	file.close();
//	// std::string arguments[] = { "123", "abc", Date{ 13 , 1 , 2019 }, "456", "def" };
//	Tape tape{ "123", "abc", Date{ 13 , 1 , 2019 }, 456, "def" };
//	service.add("123", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	service.add("1223", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	service.add("1233", "abc", Date{ 13 , 1 , 2019 }, 456, "def");
//	service.saveToFieldAgentRepository("123");
//	service.saveToFieldAgentRepository("1223");
//	service.saveToFieldAgentRepository("1233");
//	vector<Tape*> nextTape = service.getAllFromFieldAgentRepository();
//	assert(*nextTape[0] == tape);
//	for (Tape* tape : nextTape)
//		delete tape;
//	/*for (int i = 0; i < service.sizeOfFieldAgentRepository(); i++)
//		delete nextTape[i];*/
//	ofstream file1("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.csv");
//	file1 << "";
//	file1.close();
//	ofstream file2("D:/Facultate/Semestrul 2/OOP/Lab 8/testServiceMyList.csv");
//	file2 << "";
//	file2.close();
//}
//
//void Test_Service() {
//	ofstream file("D:/Facultate/Semestrul 2/OOP/Lab 8/testService.txt");
//	file << "";
//	file.close();
//
//	test_addToService_validInput_ElementAdded();
//	test_addToService_invalidInput_returnsException();
//	test_removeFromService_validInput_ElementRemoved();
//	test_removeFromService_invalidInput_returnsException();
//	test_updateFromService_validInput_ElementUpdated();
//	test_updateFromService_invalidInput_returnsException();
//	test_nextElement_ValidInput_CyclesThroughElements();
//	test_saveToFieldAgentRepository_ValidInput_ElementAdded();
//	test_saveToFieldAgentRepository_DuplicateElement_ThrowsException();
//	test_saveToFieldAgentRepository_NonexistentElement_ThrowsException();
//	test_getAllFromFieldAgentRepository_validInput_RerunsElements();
//	test_getPathFromService_validInput_pathReturned();
//	/*
//	*/
//}
//
//void testAll()
//{
//	Test_Tape();
//	Test_DynamicArray();
//	Test_MemoryRepository();
//	Test_FileRepository();
//	Test_Service();
//	/*
//	*/
//}
