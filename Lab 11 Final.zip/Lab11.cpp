#include "Lab11.h"

Lab11::Lab11(QWidget* parent) : QMainWindow(parent)
{
	ui.setupUi(this);

	// reading the config file
	ifstream configFile("config.txt");
	string repoType;
	configFile >> repoType;
	if (repoType == "memory") {
		this->service = new Service{};
		this->agentPath = "";
	}
	else if (repoType == "file")
	{
		string adminPath;
		configFile >> adminPath;
		configFile >> this->agentPath;
		this->service = new Service{ adminPath, this->agentPath };
	}

	//this->service = new Service{ "tapes.txt", "saved.txt" };
	this->populateList();
}

void Lab11::remove()
{
	try {
		this->service->remove(
			this->ui.titleLineEdit->text().toStdString()
		);
		this->populateList();
	}
	catch (exception& ex) {
		QMessageBox::critical(this, "Error", ex.what());
	}
}

void Lab11::updateTape()
{
	try {
		vector<string> date = this->splitString(this->ui.dateLineEdit->text().toStdString(), '-');
		Date creationDate{ stoi(date[DAY]),stoi(date[MONTH]),stoi(date[YEAR]) };
		this->service->update(
			this->ui.titleLineEdit->text().toStdString(),
			this->ui.locationLineEdit->text().toStdString(),
			creationDate,
			stoi(this->ui.accessCountLineEdit->text().toStdString()),
			this->ui.previewLineEdit->text().toStdString()
		);
		this->populateList();
	}
	catch (exception& ex) {
		QMessageBox::critical(this, "Error", ex.what());
	}
}

void Lab11::fillForm()
{
	int selectedIndex = this->getSelectedIndex();
	if (selectedIndex < 0)
		return;
	std::vector<TElement> selectedELements = this->service->getAll();
	TElement selectedELement = selectedELements[selectedIndex];
	this->ui.titleLineEdit->setText(QString::fromStdString(selectedELement->getTitle()));
	this->ui.locationLineEdit->setText(QString::fromStdString(selectedELement->getFilmedAt()));
	this->ui.dateLineEdit->setText(QString::fromStdString(selectedELement->getCreationDate().toString()));
	this->ui.accessCountLineEdit->setText(QString::fromStdString(std::to_string(selectedELement->getAccessCount())));
	this->ui.previewLineEdit->setText(QString::fromStdString(selectedELement->getFootagePreview()));
}

void Lab11::save()
{
	try {
		this->service->saveToFieldAgentRepository(this->ui.titleLineEdit->text().toStdString());
	}
	catch (exception& ex) {
		QMessageBox::critical(this, "Error", ex.what());
	}
}

void Lab11::open()
{
	if (this->agentPath != "")
		system(this->agentPath.c_str());
}

void Lab11::filter()
{
	std::string filmedAt = this->ui.filterLocationLineEdit->text().toStdString();
	int maximumAccesCount = std::stoi(this->ui.filterAccessCountLineEdit->text().toStdString());
	std::vector<Tape*> tapes = service->getAll();
	std::vector<Tape*> tapesToPrint;
	//std::vector<Tape*> tapesToPrint(tapes.size());
	copy_if(tapes.begin(), tapes.end(), back_inserter(tapesToPrint), [filmedAt, maximumAccesCount](Tape* tape) {
		return filmedAt == tape->getFilmedAt() && maximumAccesCount > tape->getAccessCount();
		});

	this->ui.savedFilteredListWidget->clear();
	for (Tape* tape : tapesToPrint)
		//cout << *tape << endl;
		this->ui.savedFilteredListWidget->addItem(QString::fromStdString(tape->toString()));

}

void Lab11::populateList()
{
	this->ui.tapesListWidget->clear();

	std::vector<TElement> tapes = this->service->getAll();
	for (TElement tape : tapes) {
		this->ui.tapesListWidget->addItem(QString::fromStdString(tape->toString()));
	}

}

vector<string> Lab11::splitString(std::string stringToSplit, char delimiter)
{
	vector <string> result;
	stringstream stringStream(stringToSplit);
	string token;
	while (getline(stringStream, token, delimiter))
		result.push_back(token);

	return result;
}

int Lab11::getSelectedIndex()
{
	QModelIndexList selectedIndexes = this->ui.tapesListWidget->selectionModel()->selectedIndexes();
	if (selectedIndexes.size() == 0) {
		this->ui.titleLineEdit->clear();
		this->ui.locationLineEdit->clear();
		this->ui.dateLineEdit->clear();
		this->ui.accessCountLineEdit->clear();
		this->ui.previewLineEdit->clear();
		return -1;
	}

	int selectedIndex = selectedIndexes.at(0).row();

	// QMessageBox::critical(this, "Error", string{ "da" + selectedIndex }.c_str());
	return selectedIndex;
}

void Lab11::add()
{
	try {
		vector<string> date = this->splitString(this->ui.dateLineEdit->text().toStdString(), '-');
		Date creationDate{ stoi(date[DAY]),stoi(date[MONTH]),stoi(date[YEAR]) };
		this->service->add(
			this->ui.titleLineEdit->text().toStdString(),
			this->ui.locationLineEdit->text().toStdString(),
			creationDate,
			stoi(this->ui.accessCountLineEdit->text().toStdString()),
			this->ui.previewLineEdit->text().toStdString()
		);
		this->populateList();
	}
	catch (exception& ex) {
		QMessageBox::critical(this, "Error", ex.what());
	}
}
