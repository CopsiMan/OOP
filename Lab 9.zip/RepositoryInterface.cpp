#include "RepositoryInterface.h"

RepositoryInterface::RepositoryInterface()
{
}

RepositoryInterface::~RepositoryInterface()
{
}
