#pragma once

#include <QtWidgets/QMainWindow>
#include <QtWidgets/qmessagebox.h>
#include "ui_Lab11.h"
#include "Service.h"
#include <vector>
#include <string>
#include <iostream>
#include <fstream>

#define USER_MODE 1
#define LIST_FILMED_AT 0
#define LIST_ACCES_COUNT 1
#define DAY 1
#define MONTH 0
#define YEAR 2

using namespace std;

class Lab11 : public QMainWindow
{
	Q_OBJECT

private:
	Ui::Lab11Class ui;
	string adminPath, agentPath;
	Service* service;

public:
	Lab11(QWidget *parent = Q_NULLPTR);
	vector<string> splitString(std::string stringToSplit, char delimiter);
	void populateList();

public slots:
	void add();
	void remove();
	void updateTape();
	void fillForm();
	void save();
	void open();
	void filter();
	int getSelectedIndex();
};
