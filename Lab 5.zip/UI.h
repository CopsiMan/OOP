#pragma once

#include "Service.h"
#include "Tape.h"
#include "DynamicArray.h"
#include <iostream>
using namespace std;

class UI
{
private:
	bool adminMode = false;
public:
	void Start();
};

