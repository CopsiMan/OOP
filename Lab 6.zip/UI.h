#pragma once

#include "Service.h"
#include "Tape.h"
#include "DynamicArray.h"
#include <iostream>

#define USER_MODE 1
#define FIRST_ARGUMENT 0
#define SECOND_ARGUMENT 1

class UI
{
private:
	bool adminMode = false;
public:
	void Start(); 
	std::string* parseInput(std::string userCommand);
};

