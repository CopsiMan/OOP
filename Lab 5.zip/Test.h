#pragma once

#include "Tape.h"

void Test_Tape();
void Test_DynamicArray();
void testAll();