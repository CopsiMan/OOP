#include "Test.h"
#include "DynamicArray.h"
#include "Repository.h"
#include "Service.h"

#include <assert.h>
#include <iostream>

// using namespace std;

void test_getTitle_validInput_tapeCreated() {
	Tape tape { "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	//cout << tape.getTitle();
	assert(tape.getTitle() == "F1423");
}

void test_getFilmetAt_validInput_tapeCreated() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	assert(tape.getFilmedAt() == "restaurant exterior");
}
void test_getCreationDate_validInput_tapeCreated() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	assert(tape.getCreationDate() == "01 - 13 - 2019");
}
void test_getAccessCount_validInput_tapeCreated() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	assert(tape.getAccessCount() == 7);
}
void test_getFootagePreview_validInput_tapeCreated() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	assert(tape.getFootagePreview() == "prev8.mp4");
}

void test_setTitle_validInput_titleSet() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	tape.setTitle("F14231");
	assert(tape.getTitle() == "F14231");
}

void test_setFilmedAt_validInput_filmedAtSet() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	tape.setFilmedAt("restaurant exterior1");
	assert(tape.getFilmedAt() == "restaurant exterior1");
}
void test_setCreationDate_validInput_creationDateSet() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	tape.setCreationDate("01 - 13 - 20191");
	assert(tape.getCreationDate() == "01 - 13 - 20191");
}
void test_setAccessCount_validInput_accessCountSet() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	tape.setAccessCount(8);
	assert(tape.getAccessCount() == 8);
}
void test_setFootagePreview_validInput_footagePreviewSet() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	tape.setFootagePreview("prev8.mp41");
	assert(tape.getFootagePreview() == "prev8.mp41");
}

void test_setTitle_invalidInput_ThrowsException() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	try {
		tape.setTitle("");
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}

void test_setFilmetAt_invalidInput_ThrowsException() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	try {
		tape.setFilmedAt("");
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}
void test_setCreationDate_invalidInput_ThrowsException() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	try {
		tape.setCreationDate("");
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}
void test_setAccessCount_invalidInput_ThrowsException() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	try {
		tape.setAccessCount(-3);
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}
void test_setFootagePreview_invalidInput_ThrowsException() {
	Tape tape{ "F1423", "restaurant exterior", "01 - 13 - 2019", 7, "prev8.mp4" };
	try {
		tape.setFootagePreview("");
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}

void test_addDynamicArray_validInput_ElementAdded() {
	DynamicArray<Tape*> dynamicArray{};
	Tape* tape = new Tape{};
	dynamicArray.add(tape);
	assert(dynamicArray.getSize() == 1);
	//delete a;
}

void test_removeDynamicArray_validInput_ElementRemoved() {
	DynamicArray<Tape*> dynamicArray{};
	Tape* tape = new Tape{};
	int firstPosition = 0;
	dynamicArray.add(tape);
	dynamicArray.remove(firstPosition);
	assert(dynamicArray.getSize() == 0);
	//delete a;
}

void test_getIndexDynamicArray_ReturnedIndex() {
	DynamicArray<Tape*> dynamicArray{};
	Tape* tape = new Tape{};
	int firstPosition = 0;
	dynamicArray.add(tape);
	assert(dynamicArray.getIndex(tape) == firstPosition);
}

void test_getElementDynamicArray_ReturnedElement() {
	DynamicArray<Tape*> dynamicArray{};
	Tape* tape = new Tape{};
	dynamicArray.add(tape);
	assert(*dynamicArray.getElement(dynamicArray.getIndex(tape)) == *tape);
}

void test_getSizeDynamicArray_ReturnedSize() {
	DynamicArray<Tape*> dynamicArray{};
	Tape* tape = new Tape{};
	dynamicArray.add(tape);
	assert(dynamicArray.getSize() == 1);
}

void test_increaseCapacityDynamicArray_DoublesTheCapacity() {
	DynamicArray<Tape*> dynamicArray{ 1 };
	Tape* tape = new Tape{};
	dynamicArray.add(tape);
	Tape* tape1 = new Tape{};
	dynamicArray.add(tape1);
}

void test_getElementsDynamicArray_ReturnedElements() {
	DynamicArray<Tape*> dynamicArray{ 1 };
	Tape* tape = new Tape{"!23"};
	dynamicArray.add(tape);
	Tape* tape1 = new Tape{"12321"};
	dynamicArray.add(tape1);
	Tape** tapes = dynamicArray.getElements();
	assert(*tapes[0] == *tape && *tapes[1] == *tape1); // && tapes[1] == tape1);
}

void test_removeDynamicArray_invalidInput_ThrowsException() {
	DynamicArray<Tape*> dynamicArray{};
	// this is an invalid position
	int position = 1;
	try{
		dynamicArray.remove(position);
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}

void test_getIndexDynamicArray_invalidInput_ReturnsMinusOne() {
	DynamicArray<Tape*> dynamicArray{};
	Tape* tape = new Tape{};
	assert(dynamicArray.getIndex(tape) == -1);
	delete tape;
}

void test_getElementDynamicArray_invalidInput_ThrowsException() {
	DynamicArray<Tape*> dynamicArray{};
	int invalidPosition = 3;
	try {
		dynamicArray.getElement(invalidPosition);
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}

void Test_Tape() {
	test_getTitle_validInput_tapeCreated();
	test_getFilmetAt_validInput_tapeCreated();
	test_getCreationDate_validInput_tapeCreated();
	test_getAccessCount_validInput_tapeCreated();
	test_getFootagePreview_validInput_tapeCreated();
	test_setTitle_validInput_titleSet();
	test_setFilmedAt_validInput_filmedAtSet();
	test_setCreationDate_validInput_creationDateSet();
	test_setAccessCount_validInput_accessCountSet();
	test_setFootagePreview_validInput_footagePreviewSet();;
	test_setTitle_invalidInput_ThrowsException();
	test_setFilmetAt_invalidInput_ThrowsException();
	test_setCreationDate_invalidInput_ThrowsException();
	test_setAccessCount_invalidInput_ThrowsException();
	test_setFootagePreview_invalidInput_ThrowsException();
}

void Test_DynamicArray()
{
	test_addDynamicArray_validInput_ElementAdded();
	test_removeDynamicArray_validInput_ElementRemoved();
	test_getIndexDynamicArray_ReturnedIndex();
	test_getElementDynamicArray_ReturnedElement();
	test_getSizeDynamicArray_ReturnedSize();
	test_increaseCapacityDynamicArray_DoublesTheCapacity();
	test_getElementsDynamicArray_ReturnedElements();
	test_removeDynamicArray_invalidInput_ThrowsException();
	test_getIndexDynamicArray_invalidInput_ReturnsMinusOne();
	test_getElementDynamicArray_invalidInput_ThrowsException();
}

void test_addToRepository_validInput_ElementAdded() {
	Repository repository{};
	Tape* tape = new Tape{};
	repository.add(tape);
	assert(repository.size() == 1);
}

void test_addToRepository_invalidInput_returnsException() {
	Repository repository{};
	Tape* tape = new Tape{};
	repository.add(tape);
	Tape* tape1 = new Tape{};
	try {
		repository.add(tape1);
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}
void test_removeFromRepository_validInput_ElementRemoved() {
	Repository repository{};
	Tape* tape = new Tape{};
	repository.add(tape);
	repository.remove(tape);
	assert(repository.size() == 0);
}

void test_removeFromRepository_invalidInput_returnsException() {
	Repository repository{};
	Tape* tape = new Tape{ "sad" };
	repository.add(tape);
	Tape* tape1 = new Tape{};
	try {
		repository.remove(tape1);
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}
void test_updateFromRepository_validInput_ElementUpdated() {
	Repository repository{};
	Tape* tape = new Tape{ "asd" };
	repository.add(tape);
	Tape* tape1 = new Tape{"asd","asdasd"};
	Tape tape2{ "asd","asdasd" };
	repository.update(tape1);
	assert(*repository.getAll()[0] == tape2);
}

void test_updateFromRepository_invalidInput_returnsException() {
	Repository repository{};
	Tape* tape = new Tape{ "sad" };
	repository.add(tape);
	Tape* tape1 = new Tape{};
	try {
		repository.update(tape1);
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}

void test_addToService_validInput_ElementAdded(){
	Service service{};
	// std::string arguments[] = { "123", "abc", "01 - 01 - 2000", "456", "def" };
	service.add("123", "abc", "01 - 01 - 2000", 456, "def");
	assert(service.size() == 1);
}
void test_addToService_invalidInput_returnsException(){
	Service service{};
	// std::string arguments[] = { "123", "abc", "01 - 01 - 2000", "456", "def" };
	service.add("123", "abc", "01 - 01 - 2000", 456, "def");
	try {
		service.add("123", "abc", "01 - 01 - 2000", 456, "def");
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}
void test_removeFromService_validInput_ElementRemoved(){
	Service service{};
	// std::string arguments[] = { "123", "abc", "01 - 01 - 2000", "456", "def" };
	service.add("123", "abc", "01 - 01 - 2000", 456, "def");
	service.remove("123");
	assert(service.size() == 0);
}
void test_removeFromService_invalidInput_returnsException(){
	Service service{};
	// std::string arguments[] = { "123", "abc", "01 - 01 - 2000", "456", "def" };
	service.add("123", "abc", "01 - 01 - 2000", 456, "def");
	// arguments[0] = "12312";
	try {
		service.remove("12312");
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}
void test_updateFromService_validInput_ElementUpdated(){
	Service service{};
	// std::string arguments[] = { "123", "abc", "01 - 01 - 2000", "456", "def" };
	// std::string arguments1[] = { "123", "ab2c", "021 - 01 - 20200", "4526", "d2ef" };
	Tape tape{ "123", "ab2c", "021 - 01 - 20200", 4526, "d2ef" };
	service.add("123", "abc", "01 - 01 - 2000", 456, "def");
	service.update("123", "ab2c", "021 - 01 - 20200", 4526, "d2ef");
	assert(*service.getAll()[0] == tape);
}
void test_updateFromService_invalidInput_returnsException(){
	Service service{};
	// std::string arguments[] = { "123", "abc", "01 - 01 - 2000", "456", "def" };
	// std::string arguments1[] = { "1223", "ab2c", "021 - 01 - 20200", "4526", "d2ef" };
	service.add("123", "abc", "01 - 01 - 2000", 456, "def");
	try {
		service.update("1223", "ab2c", "021 - 01 - 20200", 4526, "d2ef");
		assert(false);
	}
	catch (const char* exception) {
		assert(true);
	}
}

void Test_Repository() {
	test_addToRepository_validInput_ElementAdded();
	test_addToRepository_invalidInput_returnsException();
	test_removeFromRepository_validInput_ElementRemoved();
	test_removeFromRepository_invalidInput_returnsException();
	test_updateFromRepository_validInput_ElementUpdated();
	test_updateFromRepository_invalidInput_returnsException();
}

void Test_Service() {
	test_addToService_validInput_ElementAdded();
	test_addToService_invalidInput_returnsException();
	test_removeFromService_validInput_ElementRemoved();
	test_removeFromService_invalidInput_returnsException();
	test_updateFromService_validInput_ElementUpdated();
	test_updateFromService_invalidInput_returnsException();

}

void testAll()
{
	Test_Tape();
	Test_DynamicArray();
	Test_Repository();
	Test_Service();
}
