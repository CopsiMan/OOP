#include "Tape.h"

//Tape::Tape()
//{
//	this->title = '-';
//	this->filmedAt = '-';
//	this->creationDate = Date{};
//	this->accessCount = 0;
//	this->footagePreview = '-';
//}

Tape::Tape(std::string title, std::string filmedAt, Date creationDate, int accessCount, std::string footagePreview)
{
	/*this->setTitle(title);
	this->setFilmedAt(filmedAt);
	this->setCreationDate(creationDate);
	this->setAccessCount(accessCount);
	this->setFootagePreview(footagePreview);*/
	this->title = title;
	this->filmedAt = filmedAt;
	this->creationDate = creationDate;
	this->accessCount = accessCount;
	this->footagePreview = footagePreview;
	Tape_Validator::Validate(*this);
}

Tape::Tape(const Tape& tape)
{
	this->title = tape.getTitle();
	this->creationDate = tape.getCreationDate();
	this->filmedAt = tape.getFilmedAt();
	this->accessCount = tape.getAccessCount();
	this->footagePreview = tape.getFootagePreview();
}

std::string Tape::getTitle() const
{
	return this->title;
}

int Tape::getAccessCount() const
{
	return this->accessCount;
}

std::string Tape::setTitle(std::string title)
{
	/*
	if (title.size() == 0)
		throw "Invalid title length";
	*/
	this->title = title;
	Tape_Validator::Validate(*this);
	return this->title;
}

std::string Tape::setFilmedAt(std::string filmedAt)
{
	/*if (filmedAt.size() == 0)
		throw "Invalid filmedAt length";*/
	this->filmedAt = filmedAt;
	Tape_Validator::Validate(*this);
	return this->filmedAt;
}

Date Tape::setCreationDate(Date creationDate)
{
	/*if (creationDate.valid() == false)
		throw "Invalid creationDate";*/
	this->creationDate = creationDate;
	Tape_Validator::Validate(*this);
	return this->creationDate;
}

std::string Tape::setFootagePreview(std::string footagePreview)
{
	/*if (footagePreview.size() == 0)
		throw "Invalid footagePreview length";*/
	this->footagePreview = footagePreview;
	Tape_Validator::Validate(*this);
	return this->footagePreview;
}

int Tape::setAccessCount(int accessCount)
{
	/*if (accessCount < 0)
		throw "Invalid acces count value!";*/
	this->accessCount = accessCount;
	Tape_Validator::Validate(*this);
	return accessCount;
}

Tape& Tape::operator=(const Tape& tape)
{
	this->title = tape.title;
	this->filmedAt = tape.filmedAt;
	this->creationDate = tape.creationDate;
	this->accessCount = tape.accessCount;
	this->footagePreview = tape.footagePreview;
	//delete tape;
	return *this;
}

std::string Tape::htmlHeader()
{
	std::string header = "<!DOCTYPE html> <html> <head> <title>Tapes</title></style> </head> <body>  <table border = " + std::to_string(1) + ">  <tr> <td>Title</td> <td>Filmed at</td> <td>Creation date</td> <td>Access count</td> <td>Footage preview</td></tr>";
	return header;
}

std::string Tape::toHtml() {
	//std::string result = "<td>" + this->getTitle() + "</td> <td>" + this->getFilmedAt() + "</td> <td>" + this->getCreationDate().toString() + "</td> <td>" + std::to_string(this->getAccessCount()) +"</td> <td>" + this->getFootagePreview() + "</td> </tr> ";
	std::string result = "<tr>\n<td>" + this->getTitle() + "</td>\n<td>" + this->getFilmedAt() + "</td>\n<td>" + this->getCreationDate().toString() + "</td>\n<td>" + std::to_string(this->getAccessCount()) +"</td>\n<td>" + this->getFootagePreview() + "</td>\n</tr>";
	return result;
}

std::string Tape::htmlEnd() {
	std::string result = "</table> </body> </html>";
	return result;
}

//Tape::~Tape()
//{
//	delete &this->title;
//	delete &this->filmedAt;
//	delete &this->creationDate;
//	delete &this->footagePreview;
//	delete this;
//}

std::string Tape::getFilmedAt() const
{
	return this->filmedAt;
}

Date Tape::getCreationDate() const
{
	return this->creationDate;
}

std::string Tape::getFootagePreview() const
{
	return this->footagePreview;
}

bool operator==(const Tape& tape1, const Tape& tape2)
{
	return tape1.title == tape2.title;
}

std::istream& operator>>(std::istream& inputStream, Tape& tape)
{
	// TODO: insert return statement here

	std::string arguments;
	std::getline(inputStream, arguments);

	std::string argument;
	std::string formatedArguments;
	std::stringstream stringStream(arguments);
	while (std::getline(stringStream, argument, ','))
	{
		formatedArguments += (argument + " ");
	}
	//formatedArguments = formatedArguments.substr(0, formatedArguments.size() - 2);
	//std::cout << formatedArguments << '\n';
	std::stringstream tapeStream(formatedArguments);
	tapeStream >> tape.title >> tape.filmedAt >> tape.creationDate >> tape.accessCount >> tape.footagePreview;
	return inputStream;
}

std::ostream& operator<<(std::ostream& outputStream, const Tape& tape)
{
	// TODO: insert return statement here
	outputStream << tape.getTitle() << "," << tape.getFilmedAt() << "," << tape.getCreationDate() << "," << tape.getAccessCount() << "," << tape.getFootagePreview();
	return outputStream;
}

void Tape_Validator::Validate(const Tape& tape)
{
	std::string errors;

	if (tape.getTitle().size() == 0)
		errors += "Invalid title length \n";
	if (tape.getFilmedAt().size() == 0)
		errors += "Invalid filmedAt length \n";
	try {
		Date_Validator::Validate(tape.getCreationDate());
	}
	catch (const Date_Exception& exception) {
		//exception.what();
		errors += std::string{ exception.what() };
	}
	if (tape.getAccessCount() < 0)
		errors += "Invalid accessCount value \n";
	if (tape.getFootagePreview().size() == 0)
		errors += "Invalid fooragePreview length \n";

	if (!errors.empty())
		throw Tape_Exception(errors);
}

Tape_Exception::Tape_Exception(std::string message)
{
	this->message = message;
}

const char* Tape_Exception::what() const noexcept
{
	return this->message.c_str();
}
