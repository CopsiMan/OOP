#include "Lab10.h"

Lab10::Lab10(QWidget *parent)
	: QMainWindow(parent)
{
	ui.setupUi(this);
}
